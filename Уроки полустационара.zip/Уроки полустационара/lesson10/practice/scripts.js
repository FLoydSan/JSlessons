/* author: AlexART */
/* Creation date: 17.10.2003 */
function winResize () {	
		vline1.style.height		= body.clientHeight - 65;
		hline1.style.width		= body.clientWidth - 20;
		hline2.style.width		= body.clientWidth - 171;
		hline3.style.width		= body.clientWidth - 20;
		hline3.style.pixelTop	= body.clientHeight - 21;
		
		content.style.height = body.clientHeight - 100;
		content.style.width = body.clientWidth - 170;
		
		title.style.width = body.clientWidth - 170;
		
		copy.style.width = body.clientWidth - 170;
		copy.style.pixelTop  = body.clientHeight - 18;
}

function init() {
	window.onresize = winResize;
	winResize();	
}